using spotify_server.Models.Artist;

namespace spotify_server.Models.Folder;

public class FolderPublic  : PublicDefaultItem
{
    public FolderPublic() {}
    public FolderPublic(Folder folder, Artist.Artist[] owner, object[] contents)
    {
        this.type = "folder";
        this.id = folder.id;
        this.owner = owner;
        this.title = folder.title;
        this.contents = contents;
        this.date = folder.date;
    }
    
    public static async Task<FolderPublic> GetFolder(ItemsContext _context, Folder folder)
    {
        var owners = await ArtistPublic.GetArtist(_context, folder);

        if (owners.Length == 0)
        {
            return null;
        }
                
        List<object> contents = new List<object>();
        
        if((folder.contents == null || folder.contentsType == null) && folder.contentsType.Length != folder.contents.Length)
        {
            return null;
        }

        for (int i = 0; i < folder.contents.Length; i++)
        {
            if (folder.contentsType[i] == "folder")
            {
                var currentItem = await _context.folders.FindAsync(folder.contents[i]);
                if (currentItem != null)
                {
                    FolderPublic currentFolder = await GetFolder(_context, currentItem);
                    contents.Add(currentFolder);
                }
            }
            if (folder.contentsType[i] == "playlist")
            {
                var currentItem = await _context.playlists.FindAsync(folder.contents[i]);
                if(currentItem != null)
                    contents.Add(currentItem);
            }
            
        }
            
        FolderPublic folderPublic = new FolderPublic(folder, owners, contents.ToArray());
        return folderPublic;
    }
    
    public string type {get;set;}
    public long id {get;set;}
    public Artist.Artist[] owner {get;set;}
    public string title {get;set;}
    public object[] contents {get;set;}
    public DateTime date {get;set;}
}