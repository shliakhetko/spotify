namespace spotify_server.Models;

public enum ItemType
{
    TRACK,
    ARTIST,
    PLAYLIST,
    ALBUM,
    FOLDER,
}